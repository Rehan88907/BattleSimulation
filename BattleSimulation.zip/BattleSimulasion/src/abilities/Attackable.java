package abilities;

public interface Attackable {
    int attack();
}
